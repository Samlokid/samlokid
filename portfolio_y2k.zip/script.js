
document.addEventListener('DOMContentLoaded', () => {
    console.log("Welcome to Santiago's Y2K Portfolio!");
});
